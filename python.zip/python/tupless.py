"""
What is Tuple?
Tuple is another type of collection such as List
Only difference - tuple is written in round brackets
It is ordered and unchangeable i.e. once you create it, u can't change its value
New items can't be added and old one's can't be removed
Tuples can be deleted
"""

# define a tuple
tuple1 = ("a", "b", "c", "d", "a","e", "f", "g", "a", "d")
print(tuple1)

# accessing element using index no.
print(tuple1[3])

# no. of elements in tuple
print(len(tuple1))

# returns the frequency with which an element occurs
print(tuple1.count('a'))

# rest functions are same as list - index(), if item is present

#amother way to create a tuple -  tuple constructor
tuple2 = tuple(("a", "d", "e"))
print(tuple2)