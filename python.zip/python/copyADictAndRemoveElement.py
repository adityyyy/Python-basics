"""
1. copy()
2. dict() constructor
"""
d2 = { "Aish": "Cindrella",
       "Kartik": "Prince",
       "Elly": "Snowbell",
       "Ram": {"M": "Plant" , "E": "Animal"}}

print(d2)

dict2 =  d2.copy()
print(dict2)

dict3 = dict(d2)
print(dict3)

dict4 = dict( Aish = "Cindrella",
       Kartik= "Prince",
       Elly = "Snowbell",
       Ram= "Villain"
)
print(dict4)

"""
1. pop() - removes item with specified key name
2. popitem() - removes the last inserted element
3. del keyword with given key name
4. the del keyword to delete whole dict
5. clear() - empties the dict
"""
dict4.pop("Elly")
print(dict4)

dict4.popitem()
print(dict4)

del dict4["Kartik"]
print(dict4)

dict4.clear()
print(dict4)

del dict4
print(dict4)