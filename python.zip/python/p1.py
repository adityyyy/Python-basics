""" multi line comment
character_name="John"
character_age="75"
print(character_name +" is dumb")
print(character_name +" is "+ character_age+ "y/o")
for new line use \n 
"""
phrase="Adity Roy"
print(phrase.upper()) #to covert to uppercase
print(phrase.isupper()) #to check whewther phrase is uppercase or not
print(phrase.upper().isupper()) #to covert phrase to upper case and then check if its in uppercase or not 
print(len(phrase))
print(phrase[0]) #index to character to be grabbed
print(phrase[5])
#index function tells us about where a specific character or a string is located inside of our string
print(phrase.index("R"))
print(phrase.index("ity"))
print(phrase.replace("Adi","Enti").replace("oy","eference"))
"""
my_num=5
print(my_num + "my fav number") //this give an error becoz my num is considered as a number here """
my_num=5
print(str(my_num) + " is my fav number")#this is the correct way. first we need to convert it to string
my_num=-5
print(abs(my_num))
print(pow(my_num, 3))
print(max(4.01, 4.001))
print(min(4.01, 4.001))
print(round(3.2))
print(round(3.9))
print(round(-3.2))
print(round(-3.9))

