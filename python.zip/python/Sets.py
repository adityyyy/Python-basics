"""
SET is one more type of collection such as List and Tuple.
Set is writte in curly braces.
Sets are unordered, changeable and unindexed similar to Tuple i.e. 
Once set is created you cannot change values, 
but u can add/remove items to it similar to list and unlike Tuple.
We can also delete sets
"""
# define a set
set1 = {"A", "B", "C"}
print(set1)

# length of the set
print(len(set1))

for x in set1:
    print(x)

# using if
if "C" in set1:
    print("C is present in set1")
    
# creating the set using constructor
set2 = set(("1", "2", "3", "4", "5"))
print(set2)

s = set()
print(type(s))
s_from_list = set([1,2,3,4])
print(s_from_list)
print(type(s_from_list))
# alternate way
# l = [1,2,3,4
# s_from_list = set(l)

# NOTE: set only retains unique values
s1 = set() # empty set
s1.add(1)
s1.add(2)
print(s1)
s2 = s1.union({1,2,3,4})
print(s1,s2)
s3 = s1.intersection({3,1})
print(s1,s3)
print(len(s2))
print(max(s2))
print(min(s2))
print(s2.isdisjoint(s1))