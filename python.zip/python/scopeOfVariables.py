l=10
c=5
# NOTE- the value of global variables can't be changed inside the function unless we  use the global keyword

def function1(n):
    l=5
    m=8
    # c=c+25 this gives error
    global c # correct way
    c= c + 25
    print(l, c)
    print(l, m)
    print(n, "I have printed")

function1("This is me")
print(l)

def adi():
    x=50
    def rock():
        global x #NOTE- the interpreter will look for x outside the nested functions and here we have no global x outside the nested function so the value of x remains unchanged.
        x = 88
    print("before calling rock()", x) # prints 50
    rock()
    print("after calling rock()", x) # prints 50

adi()
