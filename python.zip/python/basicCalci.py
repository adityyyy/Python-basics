num1 = input("Enter a number: ")
num2 = input("Enter another number: ")
#print(num1+num2) wrong concept
print(int(num1)+int(num2))