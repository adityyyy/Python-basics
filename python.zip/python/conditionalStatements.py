a = 2
b = 9

# shorthand if
if(a<b): print("a is smaller than b")

# shorthand if-else
print("a is smaller than b") if(a<b) else print("a is greater than b")

a=9
# shorthand if elif else
print("a is smaller than b") if a<b else print(("a is equal to b")) if a==b else print(("a is greater than b"))
