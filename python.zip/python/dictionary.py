# DICTIONARY - contains key value pair
d1 = {}
print(type(d1))
d2 = { "Aish": "Cindrella",
       "Kartik": "Prince",
       "Elly": "Snowbell",
       "Ram": {"M": "Plant" , "E": "Animal"}}
print(d2)
print(d2["Kartik"]) #accessing values using keys

# accessing values using get method
str = d2.get("Kartik")
print(str)
d2["Alia"] = "Elizabeth" # adding new element to a dictionary
del d2["Kartik"]
print(d2)
print(d2["Ram"])
print(d2["Ram"]["E"])
print(d2.copy()) # returns the copy of the dictionary
# d3 points at d2 so if we directly delete element from d3, the element from d2 gets deleted automatically
d3=d2
del d3["Aish"]
print((d2))

# to avoid deletion of the key value pair- correct way
d3=d2.copy()
del d3["Elly"]
print(d2)
print(d3)

print(d2.get("Elly"))
d2.update({"Leena": "Princess"})
print(d2)