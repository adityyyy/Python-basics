list1 = ["Ram", "Sheela", "Ghanshyam", "Deepti"]
for item in list1:
    print(item)
list2 = [["Ram", 18], ["Sheela",20], ["Ghanshyam",11], ["Deepti", 15]]
# unpacking in list
for item,age in list2:
    print(item,age)

dict1 = dict(list2)
for item in dict1:
    print(item)
# correct way to print key-value pair using dictionary
for item, lollypop in dict1.items():
    print(item, lollypop)