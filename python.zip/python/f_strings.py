a = "adi"
# c = "this is %s" %a
# print(c)

#  This can also be done by using an alternative i.e. fstring

b = f"this is {a}"
print(b)