x = input("Enter a number: ")
while(int(x)<100):
    x = input("Enter a number: ")

# while(True):
#     inp = int(input("Enter a Number\n"))
#     if inp>100:
#         print("Congrats you have entered a number greater than 100\n")
#         break
#     else:
#         print("Try again!\n")
#         continue