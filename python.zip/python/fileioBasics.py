# FILE IO BASICS
# "r" - open file for reading -default
# "w" - open a file for writing
# "x" - creates a file if it doesn't exists
# "a" - add more content to a file
# "t" - text mode - default
# "b" -  binary mode
# "+" - read and write
# """ """

# FILE READING
# f = open("adity.txt", "r")
# content = f.read()
# print(content)


# content can be iterated

# for line in f:
#     print(line, end = "")

# print(f.readline())
# print(f.readline())
# print(f.readline())

# print(f.readlines())
#
# f.close()


# USING IF BLOCK TO OPEN A PYTHON FILE
with open("adity.txt") as f:
    a = f.read(10)
    print(a)

f = open("adity.txt", "rt")
print(f.read())
f.close()