f = open("adity.txt")
print(f.tell()) # tells where the file pointer id
print(f.read())
f.seek(4) # to set file pointer to a particular location
print(f.read())
f.close()

