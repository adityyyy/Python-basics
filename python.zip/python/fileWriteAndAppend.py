# READING A FILE

# f = open("adity.txt")
# print(f.read())

# WRITING IN A FILE

# f = open("adity.txt", "w")
# f.write("Bitchyyyyyy")
# f.close()

# APPEND IN A FILE

# f = open("adity.txt", "a")
# a = f.write("Why so dumb????????\n") # f.write() returns no. of characters written into a file
# print("The contents written in file is ", a)
# f.close()


# READ + WRITE i.e. "r+"

f = open("adity.txt", "r+")
print(f.read())
f.write("this is the last line")
f.close()