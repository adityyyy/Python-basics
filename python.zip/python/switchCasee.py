# SWITCH CASE
#
# def week(i):
#     switcher={
#         0:'Sunday',
#         1:'Monday',
#         2:'Tuesday',
#         3:'Wednesday',
#         4:'Thursday',
#         5:'Friday',
#         6:'Saturday'
#     }
#     return switcher.get(i, "Invalid day of the week")
#
# driver key
# print(week(2))
# print(week(3))
# print(week(22))



# SWITCH CASE USING DICTIONARY
# def one():
#     return "One"
# def two():
#     return "Two"
# def three():
#     return  "Three"
# def four():
#     return "Four"
# def five():
#     return "Five"
# def six():
#     return "Six"
# def default():
#     return "Number doesn't exist"
#
# #define a dictionary
# switcher = {
#     1: one,
#     2: two,
#     3: three,
#     4: four,
#     5: five,
#     6: six
# }
#
# def switch(numOneToSix):
#     return switcher.get(numOneToSix, default)()
#
# # driver code
# print(switch(6))
# print(switch(3))
# print(switch(8))


# SWITCH CASE USING CLASS
# class PythonSwitch:
#
#     def switch(self, dayOfWeek):
#         default = "Incorrect day"
#         return getattr(self, 'case_' + str(dayOfWeek), lambda: default)()
#
#     def case_1(self):
#         return "Monday"
#
#     def case_2(self):
#         return "Tuesday"
#
#     def case_3(self):
#         return "Wednesday"
#
#
# s = PythonSwitch()
#
# print(s.switch(1))
# print(s.switch(0))


# Changing Case in Switch Case

def zero():
    return "zero"


def one():
    return "one"


def two():
    return "two"


switcher = {
    0: zero,
    1: one,
    2: two
}


def numbers_to_strings(argument):
    # Get the function from switcher dictionary
    func = switcher.get(argument, "nothing")
    # Execute the function
    return func()


print(numbers_to_strings(1))

# changing the switch case
switcher[1] = two
print(numbers_to_strings(1))

""" 
Input: numbers_to_strings(1)
Output: One

Input: switcher[1]=two #changing the switch case
Input: numbers_to_strings(1)
Output: Two
"""