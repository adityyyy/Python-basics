"""
Ways to create a list
1. Using square brackets
2. Using list() constructor
"""

#define list
list1 = ["A", "B", "C", "D", "E"]
print(list1)

# using constructor method to create a list
list2 = list(("A", "B", "C", "D", "E"))
print(list2)