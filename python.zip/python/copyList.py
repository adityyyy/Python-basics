"""
How to copy a list?
you cannot copy a list by simple assigning it to another variable i.e. list2=list1
because list2 will only contain the reference to list1, and changes made to list2 will
also be seen in list1

There are two ways to copy a list:
1. copy() method
2. list() method
"""

list1=["A", "B", "C", "D"]
print(list1)

# using copy() method
list2 = list1.copy()
print(list2)

# using list() method
list3=list(list2)
print(list3)