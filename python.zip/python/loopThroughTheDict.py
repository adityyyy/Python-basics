"""
Loop Through the dictionary
You can use loops with dictionary to access keys, values and both as needed.
To access values from dictionary through loop, one can also use values()
"""

d2 = { "Aish": "Cindrella",
       "Kartik": "Prince",
       "Elly": "Snowbell",
       "Ram": {"M": "Plant" , "E": "Animal"}}

# print the keys
print("All the keys are as follows: ")
for x in d2:
    print(d2[x])

#Another method to print values, using values()
print("All the values are as follows")
for x in d2.values() :
    print(x)

# to print keys and values
for keys,values in d2.items():
    print(keys, values)