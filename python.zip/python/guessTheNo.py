n = 18
guesses_left=5
guess_count=0
while(guesses_left):
    guess_no = input("Guess the no.: ")
    guess_count+=1
    if(int(guess_no)==n):
        print("Congrats, you won. It took ", guess_count, "guesses")
        break
    else:
        if(int(guess_no)<n):
            print("Try a larger number")
        else:
            print("Try a smaller number")
        print("guesses left = ", guesses_left-1)
    guesses_left-=1
if(guesses_left==0 and n !=int(guess_no)):
    print("Try again!! You lost")
