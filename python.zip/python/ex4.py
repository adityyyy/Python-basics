n = int(input("Enter the value of n: "))
r = bool(int(input("enter a no: ")))
if  r== True:
    for i in range(0, n+1):
        print("*"*i)
if r== False:
    for i in range(n, 0, -1):
        print("*"*i)