# LISTS - it is mutable
# 1. remove() - removes specific item
# 2. pop() - removes last element if index is not specified
# 3. pop(indexNo) - Removes the specific index
# 4. del keyword with index no. deletes the specified element
# 5. del keyword without index no. deletes the whole list
# 6. clear() - empties the list, will not delete it


myList = ["alpha, beta, 5.545, 3 , 7*4 "]
print(myList) # you can access list through the index
myList1 = [1 , 4, 2, 9, 5, 11]
myList1.sort()
print(myList1)
myList1.reverse()
print(myList1)
print(myList1[0:5:2]) # never take step less than -1 in slicing
myList1.append(45) # adds new value to the end of the list
myList1.insert(1, 89) #it adds element at a particular index
print(myList1)
myList1.pop() # removes last element
myList1.remove(4)
myList1[1] = 57 # in list the value of index 1 gets changed. To avoid this we use tuple

alphabet = ["A", "B", "C", "D"]
print(len(alphabet))
alphabet.append("E") #to insert element at the end of a list
print(alphabet)
x = alphabet.index("C") #to find index of an element
print(x)
alphabet.insert(2, "F") # to insert element at a particular index
print(alphabet)

for z in alphabet:
    print(z)

if "Z" in alphabet:
    print("present")
else:
    print("not present")

# TUPLES - they are immutable

tp = (5, 3, 9, 1)
print(tp)
a = 9
b = 6
print(a,b)
a,b = b,a
print(a,b)