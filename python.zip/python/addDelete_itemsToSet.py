"""
    Adding items to set
    There are 2 ways:
    1. add() - Adds single item to set
    2. update() - Adds more than one or multiple items to set
"""

# define a set 
set = {"a", "b", "c", "d"}
print(set)

# using add()
set.add("e")
print(set)

# using update()
set.update("!", "2", "k", "#","d")
print(set) 

"""
Removing items from SET
1. remove() - removes specific item
2. discard() - removes specific item
3. pop() - removes an item, but this method will remove the last item.
Since sets are unordered we can't predict which item will be removed 
4. del keyword - to delete whoel set
5. clear() - empties the set
"""

# define a set
set1 = {"a", "b", "c", "d", "e", "f"}
print(set1)

# using remove()
set1.remove("c")
print(set1)

# using discard()
set1.discard("a")

# using pop()
removedItem = set1.pop()
print(removedItem)
print(set1)

# using clear()
set1.clear()
print(set1)

# using dek keyword
del set1
print(set1)