mystr ="You're pretty dumb"
print(mystr)                   # You're pretty dumb
print(mystr[3])                # '
print(mystr[0:4])              # You'
print(mystr[2:5])              # u'r
print(mystr[3:-2])             # 're pretty du
print(len(mystr))              # 18
print(mystr[0:19:2])           # Yur rtydm
print(mystr[::])               # You're pretty dumb
print(mystr[0:])               # You're pretty dumb
print(mystr.isalnum())         # False becozz the string contains spaces
print(mystr.endswith("dumb"))
print(mystr.isalnum())         # checks alpha numeric
print(mystr.count("u"))        # counts the number of alphabet present which is passed in the function
print(mystr.capitalize())      # makes the first character of the string a capital letter
print(mystr.find("is"))
print(mystr.lower())
print(mystr.upper())
print(mystr.replace("pretty", "way too"))
print(mystr.split(" "))
# print(mystr.split(" , "))
print(mystr.split(" a "))
a = "        hello duniya      "
print(a.strip()) #removes prefix and postfix whitespaces
