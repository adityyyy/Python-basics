# d1={"maggi": "junk food",
#     "paneer": "milk",
#     "cat": "animal",
#     "lizard": "reptile",
#     "mango": "fruit"}
#
# x = input()
# print(d1[x])

Dict = {"ignore":"refuse to take notice of or acknowledge", "abandon":"cease to support or look after",
        "exaggerate":"enlarged or altered beyond normal proportions", "prejudice":"preconceived opinion that is not based on reason or actual experience", "programming":"the process of writing computer programs"}
print("Enter the Word")
Data1 = input()
print(Data1, "means", Dict[Data1])