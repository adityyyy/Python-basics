from math import*
print(floor(3.2))
print(ceil(3.2))
print(sqrt(12))
#to take input from the user 
name = input("enter the name of the user: ")
print("Hello " + name + "!!!!!")