def factorial(n):
    """

    :param n: Integer
    :return: n*n-1*n-2*n-3*............*1
    """
    pass
