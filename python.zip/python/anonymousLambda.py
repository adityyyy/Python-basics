# LAMBDA/ ANONYMOUS FUNCTION
minus = lambda x,y: x-y
print(minus(9,4))

def a_first(a):
    return a[0]

a = [[1,6], [5,14], [8,3]]
a.sort(key=a_first) #key takes a function as a value
print(a)