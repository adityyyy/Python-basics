#functions in python
def sayHi():
    print("Hello User!!")
greeting = sayHi()
def sayHello():
    print("Hello " + name)
name = "Rahul"
name = "Shyaam"
sayHello()

