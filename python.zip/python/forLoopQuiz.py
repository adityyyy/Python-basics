list = ["cat", 3, "bat", 9, "rat", 19, 57, "jar", "cup"]
for item in list:
    if(str(item).isnumeric() and item>6):
        print(item)
