# a = input("Enter something: ")
# def printFun(var):
#     print(var)
# printFun(a)
#

# A = 15
# B = 20
#
# print(A,B)

# import math
num = 2
d = math.log10(num)
print(math.floor(d)+1)
# a=0
# b=0
# c=0
# def input1():
#     a = int(input("Enter the value of a"))
#     b = int(input("Enter the value of b"))
#     c = int(input("Enter the value of c"))
#
# def tr(a,b,c):
#     if((a==b ) or (a==c) or (b==c)):
#         print("isos")
#     else:
#         print("not isos")
#
# input1()
# tr(a,b,c)
